Source: https://github.com/ranxianglei/billion-context/tree/dc041dd1ab1a014efa352ba47a6f31fc47f55284/kernel
Commit: dc041dd1ab1a014efa352ba47a6f31fc47f55284
License: https://github.com/ranxianglei/billion-context/blob/dc041dd1ab1a014efa352ba47a6f31fc47f55284/kernel/LICENSE
ZCodium bundles the kernel library entry with one compatibility patch: tokenizer createRequire uses __filename in CommonJS and import.meta.url in ESM. Token estimates and optional BPE fallback are unchanged. The integration uses candidate primitives; no host, proxy, panel or external storage service is bundled.
Rebuild: node scripts/vendor-native-context-kernel.mjs (root locked TypeScript/esbuild).
